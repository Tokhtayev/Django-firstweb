from django.urls import path
from .views import HomePageView, AboutPageView, LinktoMohirdevView, LinktoAIView

urlpatterns = [
    path('link/', LinktoMohirdevView.as_view(), name='link'),
    path('about/', AboutPageView.as_view(), name='about' ),
    path('', HomePageView.as_view(), name='home'),
    path('ai/', LinktoAIView.as_view(), name = 'ai'),
]
