from django.test import SimpleTestCase

class SimpleTest(SimpleTestCase):
    def test_django(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_about_page(self):
        response = self.client.get('/about/')
        self.assertEqual(response.status_code, 200)
        
    def test_link_page(self):
        response = self.client.get('/link/')
        self.assertEqual(response.status_code, 200)
    
    def test_ai_page(self):
        response = self.client.get('/ai/')
        self.assertEqual(response.status_code, 200)
        
